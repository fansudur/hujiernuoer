# 已有 Landsat 真彩色背景追加（非新增研究）

3 景来自既有研究冻结 RGB/QA 数组，不是报告插图裁切，也没有下载新影像。

- 1992-07-05 Landsat 5 TM；原始 UTC 02:14:15.262019。
- 2007-07-31 Landsat 5 TM；原始 UTC 02:44:39.363069。
- 2021-07-21 Landsat 8 OLI；原始 UTC 02:51:05.591496。

运行：`/usr/bin/python3 ../scripts/reproject_historical_rgb.py`（依赖本机已有 GDAL、NumPy 及 manifest 中源文件）。参数及输入/输出 hash 见 manifest.json。

输出为 EPSG:4326 PNG，429×399；bounds 严格等于网页 terrain_context。约30m显示采样，不声称比原始30m更细。每张 PNG 另附 worldfile/PAM；网页以 manifest 的 geographic.bounds 放置。原始 UTM 栅格经 GDAL 真正重投影，非将 UTM 方形拉伸为经纬度矩形。

采用 nearest 是为了不跨 QA 无效边缘混色，逐像元继承原有 valid 掩膜，alpha 仅 0/255；不修补云、空洞、不把无效位置视作水或陆。2021大范围原研究北部云缺测较多，当前裁切范围有效率较高，二者分母范围不同。不能拿原大范围有效率与本次场地区域混用。

三景同为7月但不同日，影像日期不能替代月水体分类日期。1992-07没有当前72月水体掩膜，不能借别月或造掩膜。2007-07提供一个此前没有真彩色的水体月背景；2021-07已有 Sentinel 可选。合并后38景；当前72水月中11个月有同月真彩色，不代表完整连续年月影像。

Landsat统一固定显示拉伸，但不同于 Sentinel 显示拉伸且传感器/分辨率不同。颜色、季节/年景、图像亮度不能单独证明草地恢复、盐分、树种、蒸散变化。保持真实日期、sensor 和来源随界面可见。

来源：USGS Landsat Collection 2 Level 2，原冻结 STAC 时间及源目录记录见 manifest。匹配仍须同年同月、距场景日最近；不能跨月借图。QA透明区下只显示明确的中性地形/缺测状态，不叠加另一年的卫星影像伪装完整观测。
