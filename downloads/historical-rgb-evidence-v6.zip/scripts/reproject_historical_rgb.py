#!/usr/bin/python3
import json,hashlib,math
from pathlib import Path
import numpy as np
from osgeo import gdal,osr

gdal.UseExceptions()
R=Path('/workspace/shared/alkali_regional_land_change')
O=Path('/workspace/shared/lake_immersive_time_v6/historical_rgb');O.mkdir(exist_ok=True)
terrain=Path('/workspace/scratch/951b8192a501/lake-interactive-site/dist/data/terrain_context.json')
b=json.load(open(terrain))['bounds']
width=math.ceil((b[2]-b[0])*111320*math.cos(math.radians((b[1]+b[3])/2))/30)
height=math.ceil((b[3]-b[1])*111320/30)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
params={'source_crs':'EPSG:32650','target_crs':'EPSG:4326','output_bounds':b,'width':width,'height':height,'resampleAlg':'near','srcAlpha':True,'dstAlpha':True,'errorThreshold':0,'display_transform':'round(255*clip((DN*0.0000275-0.2-0.02)/0.33,0,1)^0.8)','quality':'Reuse frozen valid mask (cloud/shadow/snow/fill/cirrus as applicable, medium confidence, 1 pixel dilation, saturation and RGB/NIR nonzero); no water exclusion','invalid_rgb':0}
ph=hashlib.sha256(json.dumps(params,sort_keys=True,separators=(',',':')).encode()).hexdigest()
records=[]
for f in json.load(open(R/'sources/three_regional_scenes.json'))['features']:
 sid=f['id'];date=f['properties']['datetime'][:10];npz=R/'rasters'/f'{sid}_aligned_display_and_quality.npz';a=np.load(npz);rgb=a['rgb'];valid=a['valid'];h,w=valid.shape;bb=a['bounds'].tolist()
 gt=(bb[0],(bb[2]-bb[0])/w,0,bb[3],0,-(bb[3]-bb[1])/h)
 raw=gdal.Open(str(R/'raw'/f'{sid}_red.tif'))
 assert np.allclose(raw.GetGeoTransform(),gt) and raw.RasterXSize==w and raw.RasterYSize==h
 src=gdal.GetDriverByName('MEM').Create('',w,h,4,gdal.GDT_Byte);src.SetGeoTransform(gt);srs=osr.SpatialReference();srs.ImportFromEPSG(32650);src.SetProjection(srs.ExportToWkt())
 colors=[gdal.GCI_RedBand,gdal.GCI_GreenBand,gdal.GCI_BlueBand,gdal.GCI_AlphaBand]
 for i in range(3):
  v=np.rint(np.clip(rgb[:,:,i],0,1)*255).astype(np.uint8);v[~valid]=0;src.GetRasterBand(i+1).WriteArray(v);src.GetRasterBand(i+1).SetColorInterpretation(colors[i])
 src.GetRasterBand(4).WriteArray(valid.astype(np.uint8)*255);src.GetRasterBand(4).SetColorInterpretation(colors[3])
 dst=gdal.Warp('',src,format='MEM',dstSRS='EPSG:4326',outputBounds=b,width=width,height=height,resampleAlg='near',srcAlpha=True,dstAlpha=True,errorThreshold=0)
 out=O/f'{date}_landsat_truecolor_geographic.png';gdal.GetDriverByName('PNG').CreateCopy(str(out),dst,options=['WORLDFILE=YES'])
 arr=dst.ReadAsArray();alpha=arr[3];assert set(np.unique(alpha)) <= {0,255}
 assert np.all(arr[:3,alpha==0]==0)
 records.append({'id':sid,'date':date,'datetime':f['properties'].get('datetime'),'sensor':'Landsat 5 TM' if sid.startswith('LT05') else 'Landsat 8 OLI','label':f'{date} · Landsat 真彩色（30m）','kind':'satellite_true_color','bands':['red','green','blue'],'assets':{'geographic':{'path':out.name,'sha256':sha(out),'crs':'EPSG:4326','bounds':b,'size_px':[width,height],'geotransform':list(dst.GetGeoTransform())}},'bounds_wgs84':b,'coordinates':[[b[0],b[3]],[b[2],b[3]],[b[2],b[1]],[b[0],b[1]]],'source':{'local_path':str(npz),'sha256':sha(npz),'raw_red_georeference_path':str(R/'raw'/f'{sid}_red.tif'),'raw_red_sha256':sha(R/'raw'/f'{sid}_red.tif'),'crs':'EPSG:32650','geotransform':list(gt),'size_px':[w,h],'pixel_m':30,'stac_metadata_path':str(R/'sources/three_regional_scenes.json'),'stac_metadata_sha256':sha(R/'sources/three_regional_scenes.json')},'reprojection_parameters_sha256':ph,'quality':{'valid_fraction_context':float(np.mean(alpha==255)),'valid_pixels_context':int(np.sum(alpha==255)),'total_pixels_context':int(alpha.size),'display_transparent_nodata_pixels':int(np.sum(alpha==0)),'mask_basis':params['quality']},'warnings':['真彩色显示不是水体分类；透明处为质量剔除，不是无水。','相同7月仍有具体日期、传感器和当年条件差异；与 Sentinel 拉伸亦不同，颜色不直接证明生态变化。','仅重用原片与已有质量掩膜；30m 不新增细节，无实测控制点配准。','1992-07 在当前合格 JRC 月序列中没有水体掩膜，不得补造。']})
manifest={'version':1,'title':'既有三景 Landsat 真彩色：场地背景 DEM 范围重投影','attribution':'USGS Landsat Collection 2 Level 2; display derived from existing frozen research assets.','bbox_wgs84':b,'image_count':len(records),'reprojection_parameters':params,'reprojection_parameters_sha256':ph,'script_sha256':sha(__file__),'gdal_version':gdal.VersionInfo('--version'),'terrain_context_sha256':sha(terrain),'scenes':records}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({'dimensions':[width,height],'records':[(r['date'],r['quality']['valid_fraction_context']) for r in records]},indent=2))
