# 历史真彩色显示依据包

本包包含3张输出PNG、世界文件/地理参考、来源与重投影参数manifest、输入位置/哈希索引、实际运行脚本及独立QA记录。

**不是包含全部原输入的独立复算包**：原始NPZ、原red GeoTIFF、STAC与terrain_context未打包；完整重算须按input-index.json取得相同输入，并调整脚本内路径。依赖Python3、NumPy、GDAL（运行版本见manifest），执行 scripts/reproject_historical_rgb.py。没有新外部下载或新增研究。

本脚本已在保有原输入的工作环境实际成功运行；独立QA验证输出地理参考、日期、逐像元alpha及RGB，记录在qa/。不能据此声称本ZIP脱离原输入可独立重建。

与单独的 scene-time-evidence-v6.zip 区分：后者包含其时间/风JSON所需小输入，曾在新临时目录重建并验证两JSON逐字节一致；该独立复算记录不涵盖本次历史RGB。

加入历史RGB只追加背景影像，未增加水体分类或改写原研究。输出覆盖terrain_context；合并影像38景，72水月中11月有同月影像。1992-07无水体mask不补造。各影像具体日期/传感器/有效区不同；不能据跨传感器颜色差直接判定生态变化。
