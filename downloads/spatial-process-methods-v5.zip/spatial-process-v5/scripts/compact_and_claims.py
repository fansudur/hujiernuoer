from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];D=R/'data'
s=json.loads((D/'solar_geometry.json').read_text())
c={k:s[k] for k in ['schema','center','time_basis','template_year','not_observed_yearly_sunshine','paths','limits']}
c['receptors']=[{k:v for k,v in r.items() if k not in ['daily_geometry','horizon']}|{'horizon_azimuth_altitude_deg':[[x['azimuth_true_north_deg'],x['horizon_deg']] for x in r['horizon']]} for r in s['receptors']]
c['center_daily_geometry']=next(r['daily_geometry'] for r in s['receptors'] if r['id']=='C')
(D/'solar_geometry_display.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')))
claims={
 'shoreline':{'title':'湖面怎样变化，哪些地方反复接近水边？','seen':'按同月跨年或同年逐月播放真实水面分类轮廓；旧边界以年份色带和虚线保留，当前边界最醒目。','meaning':'识别水面曾经到达的位置、反复变化的交界和不同年份的差异。','reference':'曾水和反复变化区域可作为活动设施避让、岸带恢复和现场核查的优先参考范围；不以某一年退水后的裸地直接安排固定用途。','limits':'这些不是测绘水位、湖底地形、洪水重现期、法定保护线或安全承载范围。水面质感和过渡淡化是渲染，不补出观测之间的真实水位。'},
 'rainfall':{'title':'雨落到哪里，地形可能把水带向哪里？','seen':'雨滴落向地表；粒子沿30米DSM严格下降候选短线移动，在洼地、平地和数据边界停止。','meaning':'显示已有粗地形支持的局部下降方向，并暴露后续水路不确定的位置。','reference':'候选线与冲刷纹、道路交叉和已有剖面对照，可帮助确定更值得核查的地段，比较分散入渗、缓流与集中排水的适用条件。','limits':'不是某次实际降雨重演，也不是汇水区、流量、流速或入湖水量结果；粒子速度、雨滴密度为演示，不能据此直接定沟渠位置和尺寸。'},
 'solar':{'title':'太阳路径与季节辐射如何变化？','seen':'12个月代表日的太阳路径、当时方向/高度、28处地平线筛查位置，与已有辐射和日长数据对应。','meaning':'不同月份日长和太阳高度明显不同，解释季节受光背景；地形遮挡筛查与气象辐射是两个不同层面的量。','reference':'为活动时段、遮阴需求、植被和水分压力的季节判断提供背景，不直接当作蒸发或舒适度结论。','limits':'地方视太阳时，非北京时间；非闰年几何模板，非各年实测日照。没有精细建筑、树冠阴影或现场辐照验证。'},
 'terrain_profile':{'title':'西北坡地、道路和湖边高低怎样衔接？','seen':'地图选择5条既有剖面，沿线显示距离、高程和横向地表起伏分位数。','meaning':'把平面中的位置关系与高低起伏放在一起，观察是否存在明显坡降、局部起伏或平坦段。','reference':'作为候选来水路径、道路阻隔和场地利用的地形筛查依据，也提示哪里需要更细的测量。','limits':'剖面线不是已证实的流水线；30米DSM包含表面物体，穿湖的平坦值不是湖底或当期水位。'},
 'wind':{'title':'不同季节的风从哪里来？','seen':'区域风玫瑰、风向箭头与真实月份数据联动；低方向集中度时用多方向符号。','meaning':'显示区域背景风的季节差别，而非每一处地块的局地气流。','reference':'提供风暴露、遮风和活动布局的前期背景，并与土壤干湿和植被状况并看。','limits':'不是CFD；没有绕建筑、绕地形的局地风速场或盐尘输送模拟。动态箭头的移动不是现场风速实测。'}
}
(D/'process_claims.json').write_text(json.dumps(claims,ensure_ascii=False,indent=2))
print((D/'solar_geometry_display.json').stat().st_size)
import hashlib
m=json.loads((R/'manifest.json').read_text());m['output_files']=[{'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.is_file()];m['scripts']=[{'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((R/'scripts').glob('*.py'))];(R/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
