#!/usr/bin/python3
"""Package frozen evidence and derive coarse, strictly-descending DSM display paths.
No hydrological runoff simulation, no depression filling, no future lake levels.
Run /usr/bin/python3 scripts/build_spatial_process.py. Source roots overrideable.
"""
from pathlib import Path
import csv,json,math,hashlib,os,datetime,sys
import numpy as np
from osgeo import gdal
from pyproj import Transformer

gdal.UseExceptions()
ROOT=Path(__file__).resolve().parents[1]
LOCAL=Path(os.environ.get('LAKE_LOCAL_SOURCE','/workspace/shared/alkali_local_inflow/data'))
MICRO=Path(os.environ.get('LAKE_MICRO_SOURCE','/workspace/shared/lake_integrated_20261026/microclimate'))
OUT=ROOT/'data';OUT.mkdir(exist_ok=True)
used=[]
def readcsv(p):
 used.append(p)
 with p.open(encoding='utf-8-sig') as f:return [dict(r) for r in csv.DictReader(f)]
def numrows(rows):
 out=[]
 for r in rows:
  d={}
  for k,v in r.items():
   try:d[k]=float(v)
   except (ValueError,TypeError):d[k]=v
  out.append(d)
 return out
def save(name,data):
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,allow_nan=False,separators=(',',':')))
def readjson(p):used.append(p);return json.loads(p.read_text())
axes=readjson(LOCAL/'profile_axes.geojson')
profiles=[]
for f in axes['features']:
 pid=f['properties']['id'];p=LOCAL/f'profile_{pid}.csv';rows=numrows(readcsv(p))
 assert all(rows[i]['distance_m']<rows[i+1]['distance_m'] for i in range(len(rows)-1))
 profiles.append({'id':pid,'name':f['properties']['name'],'properties':f['properties'],'geometry':f['geometry'],'samples':rows,'evidence_type':'historical_DSM_profile','interpretation':'地表模型剖面，不是水流路线，也不是湖底测量。'})
save('terrain_profiles.json',{'schema':'lake.spatial-profiles.v1','crs':'EPSG:4326','elevation_reference':'source DSM metres; not measured current ground/water elevation','profiles':profiles,'source':'冻结历史DSM剖面，原CSV数值无改动','limits':['30米级地表模型，非精细裸地测量','跨湖平坦值不得解释为湖底深度','剖面走向不是已验证排水路线']})
receptors=numrows(readcsv(MICRO/'tables/terrain_receptors.csv'))
horiz=numrows(readcsv(MICRO/'tables/terrain_horizon_profiles.csv'))
daily=numrows(readcsv(MICRO/'tables/solar_geometry_daily_all_receptors.csv'))
qa=readjson(MICRO/'qa/terrain_solar_qa.json')
center=next(r for r in receptors if r['id']=='C');lat=math.radians(center['latitude'])
paths=[]
for month in range(1,13):
 date=datetime.date(2025,month,21);doy=date.timetuple().tm_yday;dec=.409*math.sin(2*math.pi/365*doy-1.39)
 points=[]
 for minute in range(0,1440,10):
  hour=minute/60;ha=math.radians((hour-12)*15)
  east=-math.cos(dec)*math.sin(ha);north=math.cos(lat)*math.sin(dec)-math.sin(lat)*math.cos(dec)*math.cos(ha)
  up=math.sin(lat)*math.sin(dec)+math.cos(lat)*math.cos(dec)*math.cos(ha)
  alt=math.degrees(math.asin(max(-1,min(1,up))));az=math.degrees(math.atan2(east,north))%360
  if alt>0:points.append({'solar_hour':hour,'azimuth_deg_from_true_north':az,'altitude_deg':alt,'unit_vector_enu':[east,north,up]})
 paths.append({'month':month,'date_template':str(date),'day_of_year':doy,'points':points})
byid={r['id']:{**r,'horizon':[],'daily_geometry':[]} for r in receptors}
for r in horiz:byid[r['id']]['horizon'].append(r)
for r in daily:byid[r['id']]['daily_geometry'].append(r)
save('solar_geometry.json',{'schema':'lake.solar-geometry.v1','center':center,'time_basis':'local apparent solar time, NOT Beijing civil time','template_year':2025,'not_observed_yearly_sunshine':True,'paths':paths,'receptors':list(byid.values()),'frozen_qa':qa,'limits':['太阳路径是非闰年天文几何模板，不是逐年日照实测','地平线基于历史DSM，未模拟建筑树冠精细阴影','太阳轨迹不能直接当成实测辐射或蒸发量','图上太阳弧半径为讲解比例，不是太阳实际位置']})
# Only downhill surface candidates. Strictly lower neighbours prevents cycles.
pdem=LOCAL/'local_dem_utm50n30m.tif';pwbm=LOCAL/'local_wbm_utm50n30m.tif';used.extend([pdem,pwbm])
ds=gdal.Open(str(pdem));z=ds.ReadAsArray().astype(float);gt=ds.GetGeoTransform();water=gdal.Open(str(pwbm)).ReadAsArray();H,W=z.shape
assert gt[1]==30 and gt[5]==-30 and z.shape==water.shape and np.isfinite(z).all()
tr=Transformer.from_crs(32650,4326,always_xy=True)
step=np.full((H,W,2),-1,dtype=int)
offsets=[(-1,0),(0,1),(1,0),(0,-1),(-1,1),(1,1),(1,-1),(-1,-1)]
maxslope=np.zeros((H,W))
for dr,dc in offsets:
 rs=slice(max(0,-dr),min(H,H-dr));cs=slice(max(0,-dc),min(W,W-dc))
 rn=slice(max(0,dr),min(H,H+dr));cn=slice(max(0,dc),min(W,W+dc))
 slope=(z[rs,cs]-z[rn,cn])/(30*math.hypot(dr,dc))
 good=slope>maxslope[rs,cs]+1e-12
 rr,cc=np.indices(slope.shape);rr+=max(0,-dr);cc+=max(0,-dc)
 step[rr[good],cc[good],0]=rr[good]+dr;step[rr[good],cc[good],1]=cc[good]+dc;maxslope[rs,cs][good]=slope[good]
features=[]
for r0 in range(8,H-8,12):
 for c0 in range(8,W-8,12):
  if water[r0,c0]>0:continue
  r,c=r0,c0;cells=[];status='step_limit'
  for k in range(180):
   cells.append((r,c))
   if water[r,c]>0:status='historical_water_mask';break
   if r in (0,H-1) or c in (0,W-1):status='source_edge';break
   nr,nc=step[r,c]
   if nr<0:status='flat_or_local_depression';break
   r,c=int(nr),int(nc)
  if len(cells)<5:continue
  x=np.array([gt[0]+(c+.5)*30 for r,c in cells]);y=np.array([gt[3]-(r+.5)*30 for r,c in cells]);lo,la=tr.transform(x,y)
  zz=[z[r,c] for r,c in cells];assert all(a>b for a,b in zip(zz,zz[1:]));dist=sum(math.hypot(x[i+1]-x[i],y[i+1]-y[i]) for i in range(len(x)-1))
  features.append({'type':'Feature','properties':{'id':f'descent_{r0}_{c0}','evidence_type':'coarse_DSM_derived_potential_descent','not_observed_flow':True,'length_m':round(dist,2),'drop_m':round(zz[0]-zz[-1],3),'stop_reason':status,'seed_row':r0,'seed_col':c0,'cell_count':len(cells)},'geometry':{'type':'LineString','coordinates':[[round(float(a),8),round(float(b),8),float(c)] for a,b,c in zip(lo,la,zz)]}})
# Keep all candidates for evidence; a deterministic spatially stratified display subset.
features.sort(key=lambda f:(f['properties']['seed_row'],f['properties']['seed_col']))
selected=features[::max(1,math.ceil(len(features)/120))]
limits=['逐格最陡下降只是潜在地表下降方向，不是实测水流','未填洼、未穿越平地、未烧入沟渠、未校核涵洞/道路；局部洼地会终止','只在现有局部DSM内计算，不是完整汇水区或入湖水量模型','雨滴数量、速度、动画流速均为示意，不代表某次降雨、流量或传播时间','历史水体mask终止不等于验证接通当前湖面','DSM含建筑植被等表面影响，不是精细裸地DEM']
save('potential_descent_paths.geojson',{'type':'FeatureCollection','name':'30米DSM潜在下降路径（非实测径流）','features':selected,'method':{'crs_calculation':'EPSG:32650','pixel_size_m':30,'algorithm':'strict steepest descent among 8 neighbours; distance-normalised drop','depression_filling':False,'flat_routing':False,'road_culvert_conditioning':False,'seed_spacing_m':360,'maximum_cells':180,'selection':'row-major systematic subsample to <=120 paths','all_candidate_count':len(features),'display_path_count':len(selected)},'limits':limits})
# Short provenance includes all source hashes, not external services.
manifest={'schema':'lake.spatial-process.manifest.v1','run_status':'executed_successfully','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':'scripts/build_spatial_process.py','python':sys.version,'sources':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in dict.fromkeys(used)],'checks':{'profiles':len(profiles),'solar_receptors':len(receptors),'solar_days_per_receptor':365,'solar_paths':len(paths),'horizon_rows':len(horiz),'all_paths_strictly_descending':True,'potential_route_candidates':len(features),'display_routes':len(selected),'no_fabricated_lake_levels':True,'no_new_external_data':True}}
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest['checks'],ensure_ascii=False,indent=2))
