#!/bin/sh
set -eu
cd "$(dirname "$0")"
export LAKE_LOCAL_SOURCE="$PWD/inputs/local"
export LAKE_MICRO_SOURCE="$PWD/inputs/micro"
PYTHON="${PYTHON:-/usr/bin/python3}"
"$PYTHON" scripts/build_spatial_process.py
"$PYTHON" scripts/compact_and_claims.py
