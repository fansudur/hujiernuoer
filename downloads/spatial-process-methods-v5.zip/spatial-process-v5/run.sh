#!/bin/sh
set -eu
cd "$(dirname "$0")"
/usr/bin/python3 scripts/build_spatial_process.py
/usr/bin/python3 scripts/compact_and_claims.py
