#!/usr/bin/env python3
"""Derive a display-only monthly wind rose from frozen daily POWER values. No network."""
import csv,json,math,hashlib,calendar,datetime,pathlib,sys,os
R=pathlib.Path(__file__).resolve().parents[1]
(R/'data').mkdir(parents=True,exist_ok=True)
I=pathlib.Path(os.environ['LAKE_TIME_INPUTS']) if os.environ.get('LAKE_TIME_INPUTS') else None
S=I/'site_data' if I else pathlib.Path('/workspace/scratch/951b8192a501/lake-interactive-site/dist/data')
D=I/'power_daily.csv' if I else pathlib.Path('/workspace/shared/lake_integrated_20261026/analysis/input/power_daily.csv')
rows=list(csv.DictReader(D.open()))
frozen=json.load((S/'linked/wind.json').open())['monthly']
lookup={x['date']:x for x in frozen}
groups={}
for r in rows: groups.setdefault(r['date_UTC'][:7],[]).append(r)
names=['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']
out=[]; checks=[]
for date, rr in sorted(groups.items()):
 valid=[r for r in rr if math.isfinite(float(r['WS10M'])) and math.isfinite(float(r['WD10M'])) and float(r['WS10M'])>=.5]
 bins=[]
 for i,name in enumerate(names):
  selected=[r for r in valid if int(math.floor(((float(r['WD10M'])%360)+11.25)/22.5))%16==i]
  bins.append({'sector':name,'from_deg':i*22.5,'to_deg':(i*22.5+180)%360,'n_days':len(selected),'pct_noncalm_days':100*len(selected)/len(valid) if valid else None,'mean_WS10M_m_s':sum(float(r['WS10M']) for r in selected)/len(selected) if selected else None})
 z=sum(complex(math.cos(math.radians(float(r['WD10M']))),math.sin(math.radians(float(r['WD10M'])))) for r in valid)/len(valid) if valid else 0j
 mean=math.degrees(math.atan2(z.imag,z.real))%360 if valid else None
 raw={'date':date,'n_days':len(rr),'n_direction_days':len(valid),'calm_days_lt0_5':len(rr)-len(valid),'calm_pct_all_days':100*(len(rr)-len(valid))/len(rr),'speed_m_s':sum(float(r['WS10M']) for r in rr)/len(rr),'from_deg':mean,'to_deg':(mean+180)%360 if mean is not None else None,'R':abs(z),'dispersed':abs(z)<.35,'bins':bins}
 old=lookup[date]
 raw['shortwave_daily_mean_MJ_m2_day']=old['SWD_dailymean_MJ_m2_day']
 assert abs(raw['shortwave_daily_mean_MJ_m2_day']-sum(float(r['ALLSKY_SFC_SW_DWN']) for r in rr)/len(rr))<1e-7
 assert len(rr)==calendar.monthrange(*map(int,date.split('-')))[1]
 assert len(valid)==int(old['n_direction_days'])
 assert abs(raw['speed_m_s']-old['speed_m_s'])<1e-7
 assert abs(raw['R']-old['R'])<1e-7
 assert min(abs(mean-old['from_deg']),360-abs(mean-old['from_deg']))<1e-7
 assert sum(x['n_days'] for x in bins)==len(valid)
 assert abs(sum(x['pct_noncalm_days'] for x in bins)-100)<1e-8
 out.append(raw)
assert len(rows)==14975 and len(out)==492
obj={'schema':'lake.monthly-windrose.v1','source':'Frozen NASA POWER daily regional 10 m wind, 1985–2025','date_basis':'UTC daily source dates grouped by calendar month, not local hourly weather','units':{'speed_m_s':'m/s, 10 m daily-mean wind summarized by month','from_deg':'meteorological direction FROM, clockwise from true north','to_deg':'display travel direction TO = (FROM+180)%360','shortwave_daily_mean_MJ_m2_day':'regional monthly mean of daily all-sky surface shortwave, MJ/m²/day; NOT instantaneous scene irradiance or cloud observation'},'calm_rule':'WS10M dailymean < 0.5 m/s excluded from direction bins; monthly mean speed retains all valid days','bin_rule':'16 equal 22.5 degree sectors, north centered at 0 degrees; floor(((WD mod 360)+11.25)/22.5) mod16','denominator':'valid non-calm DAYS in each month; not hourly duration or instantaneous wind frequency','display_rule':'Spatial density or sequential representative arrows may reflect bin proportions, but are regional background illustrations, not local CFD or actual chronology. All nonzero bins are retained.','monthly':out}
(R/'data/monthly_windrose.json').write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')))
shore=json.load((S/'linked/shoreline_index.json').open())['samples']; sat=json.load((S/'satellite/manifest.json').open())['scenes']
coverage={'schema':'lake.scene-time-coverage.v1','water':{'count':len(shore),'dates':sorted(x['date'] for x in shore),'meaning':'qualified monthly classified water extent; not instantaneous water level'},'satellite':{'count':len(sat),'dates':[x['date'] for x in sat],'scenes':[{'date':x['date'],'datetime_utc':x.get('datetime'),'path':x['assets']['geographic']['path']} for x in sat],'matching':'same YYYY-MM only, minimum absolute day distance to scene day, ties earlier date; absence returns null'},'wind':{'count':len(out),'start':out[0]['date'],'end':out[-1]['date'],'dates':[x['date'] for x in out],'meaning':'regional month statistics of dailymean 10m wind; not weather at solar-hour slider'},'solar':{'basis':'FAO-type approximate solar declination and ENU geometry on selected calendar date; local apparent solar time','latitude_deg':49.132794782364805,'longitude_deg':119.69156942008443,'default_scene_day':21,'default_solar_hour':12,'not_weather_observation':True,'original_template':'2025 nonleap geometry reused as algorithm, not historical solar observations'}}
assert len(shore)==72 and len(sat)==35
(R/'data/scene_time_coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2))
manifest={'schema':'lake.time-data-provenance.v1','executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':sys.version,'script':'scripts/build_time_data.py','inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [D,S/'linked/wind.json',S/'linked/shoreline_index.json',S/'satellite/manifest.json']],'checks':{'daily_rows':len(rows),'monthly_rows':len(out),'direction_counts_match_frozen':True,'monthly_speed_R_mean_direction_match_frozen_tolerance':1e-7,'all_16_bin_counts_sum_to_valid_noncalm_days':True,'all_percentages_sum_to_100':True,'water_dates':len(shore),'satellite_dates':len(sat)},'outputs':[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((R/'data').glob('*.json'))]}
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)); print(json.dumps(manifest['checks']))
