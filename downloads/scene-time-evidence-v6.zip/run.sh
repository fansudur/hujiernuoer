#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export LAKE_TIME_INPUTS="$HERE/inputs"
python3 "$HERE/scripts/build_time_data.py"
