import os
os.environ.update(GDAL_HTTP_TIMEOUT='35',GDAL_HTTP_MAX_RETRY='1',GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR',CPL_VSIL_CURL_ALLOWED_EXTENSIONS='.tif')
from pathlib import Path
import json,math,hashlib,concurrent.futures
import numpy as np
from osgeo import gdal,osr
from scipy.ndimage import binary_dilation
gdal.UseExceptions();R=Path(__file__).parent
f=json.load(open(R/'source_stac.json'))
b=json.load(open(R/'bounds.json'))
s=osr.SpatialReference();s.ImportFromEPSG(4326);s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER);t=osr.SpatialReference();t.ImportFromEPSG(32650);t.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER);tf=osr.CoordinateTransformation(s,t)
pts=[tf.TransformPoint(x,y) for x,y in [(b[0],b[1]),(b[0],b[3]),(b[2],b[1]),(b[2],b[3])]]
ub=[math.floor(min(p[0] for p in pts)/20)*20-20,math.floor(min(p[1] for p in pts)/20)*20-20,math.ceil(max(p[0] for p in pts)/20)*20+20,math.ceil(max(p[1] for p in pts)/20)*20+20];w=round((ub[2]-ub[0])/10);h=round((ub[3]-ub[1])/10)
def fetch(k):
 out=R/(k+'.tif')
 if not out.exists():raise FileNotFoundError('Frozen input missing; offline reproduction never fetches: '+str(out))
 d=gdal.Open(str(out));print(k,d.RasterXSize,d.RasterYSize,flush=True);return k,d.ReadAsArray()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:a=dict(ex.map(fetch,['red','green','blue','scl']))
valid=~binary_dilation(np.isin(a['scl'],[0,1,3,8,9,10,11]),iterations=2)
for k in ['red','green','blue']:valid&=a[k]>0
src=gdal.GetDriverByName('MEM').Create('',w,h,4,gdal.GDT_Byte);src.SetProjection(t.ExportToWkt());src.SetGeoTransform((ub[0],10,0,ub[3],0,-10))
for i,k in enumerate(['red','green','blue']):
 m=f['assets'][k]['raster:bands'][0];r=a[k]*m['scale']+m.get('offset',0);v=np.rint(np.clip(r/.3,0,1)**(1/1.6)*255).astype('uint8');v[~valid]=0;src.GetRasterBand(i+1).WriteArray(v);src.GetRasterBand(i+1).SetColorInterpretation([gdal.GCI_RedBand,gdal.GCI_GreenBand,gdal.GCI_BlueBand][i])
src.GetRasterBand(4).WriteArray(valid.astype('uint8')*255);src.GetRasterBand(4).SetColorInterpretation(gdal.GCI_AlphaBand)
ow=math.ceil((b[2]-b[0])*111320*math.cos(math.radians((b[1]+b[3])/2))/10);oh=math.ceil((b[3]-b[1])*111320/10)
dst=gdal.Warp('',src,format='MEM',dstSRS='EPSG:4326',outputBounds=b,width=ow,height=oh,resampleAlg='near',srcAlpha=True,dstAlpha=True,errorThreshold=0)
p=R/'2026-08-08_context_S2_geographic.png';gdal.GetDriverByName('PNG').CreateCopy(str(p),dst,options=['WORLDFILE=YES']);aa=dst.ReadAsArray()[3];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m={'date':'2026-08-08','datetime':f['properties']['datetime'],'id':f['id'],'sensor':'Sentinel-2A MSI','purpose':'Fixed-date whole-context backdrop only; not selected-year observation','bounds_wgs84':b,'crs':'EPSG:4326','size_px':[ow,oh],'native_rgb_pixel_m':10,'native_scl_pixel_m':20,'source_crop_utm_bounds':ub,'valid_fraction':float(np.mean(aa==255)),'invalid_pixels':int(np.sum(aa==0)),'qa_rule':'SCL 0,1,3,8,9,10,11 excluded; two 10m binary-dilation iterations (cross structure); all RGB DN>0. No gap filling.','display_transform':'clip((DN*0.0001-0.1)/0.3,0,1)^(1/1.6); nearest reproject RGBA EPSG32650 to4326','assets':{'geographic':{'path':p.name,'sha256':sha(p),'bounds':b,'crs':'EPSG:4326','size_px':[ow,oh]}},'sources':{k:{'href':f['assets'][k]['href'],'crop_path':k+'.tif','crop_sha256':sha(R/(k+'.tif'))} for k in a},'attribution':'Contains modified Copernicus Sentinel data (2026). Earth Search public COG distribution.','license':'Copernicus Sentinel data free/full/open access, subject to source acknowledgement; see accompanying verified license reference.','script_sha256':sha(__file__),'warnings':['Fixed actual-date background does not represent other selected years/months.','QA gaps remain transparent; no synthetic cloud filling.','10m RGB /20m SCL; no field-control alignment validation.']}
(R/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print('DONE',m['valid_fraction'],[ow,oh],flush=True)
