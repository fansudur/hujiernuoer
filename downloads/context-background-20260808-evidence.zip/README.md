# 固定日期的全域卫星背景（2026-08-08）

只为补齐网页 terrain_context 背景，不扩展湖泊科学分析，不新增湖岸线或水位。

2026-08-08T03:04:32.443000Z Sentinel-2A MSI。来源为既有研究冻结 STAC 中记录的 Earth Search 公开 Sentinel-2 C1 L2A COG；此次只读覆盖 context 的 RGB/SCL 窗口。RGB 原生10m，SCL20m。校准依据资产元数据 scale0.0001、offset-0.1。输出EPSG4326、1285×1197，bounds精确等于 terrain_context。输出近似10m采样，不声称实测配准或地籍精度。

质量规则：SCL0/1/3/8/9/10/11剔除，映射到10m后2次十字结构膨胀；RGB各波段DN>0；无效像元透明，不补造云下。此次context有效像元100%，只是这一规则的结果，不代表绝对无云、无薄雾或所有地物分类可信。太阳、风与湖水演示不能由这张固定背景推断。显示拉伸clip(反射率/0.3,0,1)^(1/1.6)。

界面必须写明“全域背景：2026-08-08（固定参考）”，且与“历史观测：所选年月/实际影像日期”区别。历史变化只在实际历史影像范围内讨论。不能令背景被误认为所选历史年份，也不要将背景水面与历史水面混为一次观测。该背景不增加当前72月水体序列覆盖。

## 许可与署名

Contains modified Copernicus Sentinel data (2026).

已核验官方许可：
- https://cds.climate.copernicus.eu/licences/ec-sentinel
- https://dataspace.copernicus.eu/terms-and-conditions

Sentinel数据允许依法复制、传播、修改并与其他数据组合；修改后须标明来源。此处使用的是Sentinel数据，不是CDSE网页其他受限制内容，也不是商业地图瓦片。官方不提供适用性保证。

## 复算

`/usr/bin/python3 build.py`；需NumPy、SciPy、GDAL，并需源STAC及terrain_context路径存在。当前目录保留4个实际下载窗口GeoTIFF、source_stac.json、输出PNG/世界文件/PAM、参数与hash manifest。已有原片时不再次请求网络。未包含所有原始完整卫星瓦片，仅保留必要的context窗口。没有调用付费API。


## 本下载包离线入口

本包包含4个冻结窗口输入与STAC/边界；运行 `/usr/bin/python3 reproduce_offline.py` 不访问网络。已在全新临时目录运行并确认PNG逐字节一致，记录见REPRODUCTION_CHECK.json。需本机安装NumPy/SciPy/GDAL。original_acquisition_and_render.py保留原采集流程作为方法依据，其绝对路径不是本包离线入口。manifest里的部分原工作区路径用于溯源，不影响离线入口。
